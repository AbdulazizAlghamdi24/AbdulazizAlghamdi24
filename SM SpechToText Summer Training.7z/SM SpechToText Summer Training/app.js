
class speechRecognitionApi{
    constructor(options) {
        const SpeechToText = window.speechRecognition || window.webkitSpeechRecognition;
         this.SpeechApi = new SpeechToText();
         this.output = options.output ? options.output : document.createElement("div");
         this.SpeechApi.continous = true;
         this.SpeechApi.interimResult = false;
         this.SpeechApi.onresult = (event) => {
            var resultIndex = event.resultIndex;
            var transcript = event.result[resultIndex][0].transcript;
            this.output.textContent = transcript;
         }
    }

    init() {
        this.SpeechApi.start();
    }
    stop() {
        this.SpeechApi.stop();
    }

}
window.onload = function () {
    var speech = new speechRecognitionApi({
        output: document.querySelector(".output")
        
    })

    document.querySelector(".btn-start").addEventListener("click", () =>{
        speech.init();
        
    })
    document.querySelector(".btn-end").addEventListener("click", () =>{
        speech.stop();
        
    })

}